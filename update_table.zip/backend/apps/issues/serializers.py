from django.contrib.auth import get_user_model
from rest_framework import serializers

from apps.accounts.serializers import UserBriefSerializer

from . import permissions as perms
from .models import Attachment, Category, Issue, IssueEvent, IssueUpdate, Remark

User = get_user_model()


class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ["id", "name", "slug", "description"]


class AttachmentSerializer(serializers.ModelSerializer):
    url = serializers.SerializerMethodField()

    class Meta:
        model = Attachment
        fields = ["id", "url", "original_name", "content_type", "size", "created_at"]

    def get_url(self, obj):
        url = obj.file.url
        request = self.context.get("request")
        if request and url.startswith("/"):
            return request.build_absolute_uri(url)
        return url


class IssueListSerializer(serializers.ModelSerializer):
    """Compact card for the board and lists."""

    category = CategorySerializer(read_only=True)
    created_by = UserBriefSerializer(read_only=True)
    assignees = UserBriefSerializer(many=True, read_only=True)
    status_label = serializers.CharField(source="get_status_display", read_only=True)

    class Meta:
        model = Issue
        fields = [
            "id",
            "title",
            "category",
            "priority",
            "status",
            "status_label",
            "created_by",
            "assignees",
            "is_escalated",
            "reopened_count",
            "upvote_count",
            "my_support",
            "created_at",
            "updated_at",
        ]

    my_support = serializers.SerializerMethodField()

    def get_my_support(self, obj) -> str | None:
        """'PUBLIC' / 'PRIVATE' if the viewer supports this issue, else null.
        Uses the `_my_support` annotation from the view (no extra query)."""
        value = getattr(obj, "_my_support", None)
        if value is None:
            return None
        return "PRIVATE" if value else "PUBLIC"


class IssueTableSerializer(IssueListSerializer):
    """One row of the table view: card fields + tags, faculty and the latest update / remark."""

    tagged_members = UserBriefSerializer(many=True, read_only=True)
    faculty = UserBriefSerializer(read_only=True)
    last_update = serializers.SerializerMethodField()
    last_remark = serializers.SerializerMethodField()

    class Meta(IssueListSerializer.Meta):
        fields = IssueListSerializer.Meta.fields + ["tagged_members", "faculty", "last_update", "last_remark"]

    @staticmethod
    def _latest(obj, prefix):
        body = getattr(obj, f"{prefix}_body", None)
        if body is None:
            return None
        return {
            "body": body,
            "author": getattr(obj, f"{prefix}_author", "") or "",
            "created_at": getattr(obj, f"{prefix}_at", None),
            **({"type": getattr(obj, f"{prefix}_type", None)} if prefix == "_lr" else {}),
        }

    def get_last_update(self, obj) -> dict | None:
        return self._latest(obj, "_lu")

    def get_last_remark(self, obj) -> dict | None:
        return self._latest(obj, "_lr")


class MyIssueSerializer(IssueListSerializer):
    """'Issues by you' — adds escalate/reopen availability."""

    can_escalate = serializers.SerializerMethodField()
    can_reopen = serializers.SerializerMethodField()
    escalation_available_at = serializers.SerializerMethodField()

    class Meta(IssueListSerializer.Meta):
        fields = IssueListSerializer.Meta.fields + [
            "can_escalate",
            "can_reopen",
            "escalation_available_at",
            "completed_at",
        ]

    def get_can_escalate(self, obj):
        return perms.can_escalate(self.context["request"].user, obj)

    def get_can_reopen(self, obj):
        return perms.can_reopen(self.context["request"].user, obj)

    def get_escalation_available_at(self, obj):
        return perms.escalation_available_at(obj)


class IssueDetailSerializer(IssueListSerializer):
    tagged_members = UserBriefSerializer(many=True, read_only=True)
    faculty = UserBriefSerializer(read_only=True)
    attachments = serializers.SerializerMethodField()
    permissions = serializers.SerializerMethodField()
    has_upvoted = serializers.SerializerMethodField()
    escalation_available_at = serializers.SerializerMethodField()

    class Meta(IssueListSerializer.Meta):
        fields = IssueListSerializer.Meta.fields + [
            "description",
            "tagged_members",
            "faculty",
            "escalated_at",
            "resolution",
            "completed_at",
            "last_reopened_at",
            "attachments",
            "permissions",
            "has_upvoted",
            "escalation_available_at",
        ]

    def get_attachments(self, obj):
        # Only files attached to the issue itself (not to updates/remarks).
        items = [a for a in obj.attachments.all() if a.update_id is None and a.remark_id is None]
        return AttachmentSerializer(items, many=True, context=self.context).data

    def get_permissions(self, obj):
        return perms.permission_flags(self.context["request"].user, obj)

    def get_has_upvoted(self, obj):
        user = self.context["request"].user
        return obj.upvotes.filter(user=user).exists()

    def get_escalation_available_at(self, obj):
        return perms.escalation_available_at(obj)


class IssueCreateSerializer(serializers.Serializer):
    title = serializers.CharField(max_length=120)
    description = serializers.CharField(max_length=2000)
    category = serializers.PrimaryKeyRelatedField(queryset=Category.objects.filter(is_active=True))
    priority = serializers.ChoiceField(choices=Issue.Priority.choices, default=Issue.Priority.MEDIUM)
    tagged_members = serializers.PrimaryKeyRelatedField(
        queryset=User.objects.filter(is_active=True), many=True, required=False
    )
    attachments = serializers.ListField(
        child=serializers.FileField(), required=False, allow_empty=True, write_only=True
    )


class IssueEditSerializer(serializers.Serializer):
    title = serializers.CharField(max_length=120, required=False)
    description = serializers.CharField(max_length=2000, required=False)
    priority = serializers.ChoiceField(choices=Issue.Priority.choices, required=False)
    category = serializers.PrimaryKeyRelatedField(
        queryset=Category.objects.filter(is_active=True), required=False
    )


class StatusChangeSerializer(serializers.Serializer):
    status = serializers.ChoiceField(choices=Issue.Status.choices)
    update = serializers.CharField(max_length=1000, required=False, allow_blank=True, default="")
    resolution = serializers.ChoiceField(
        choices=Issue.Resolution.choices, required=False, allow_blank=True, default=""
    )
    attachments = serializers.ListField(child=serializers.FileField(), required=False)


class AssignSerializer(serializers.Serializer):
    assignees = serializers.PrimaryKeyRelatedField(
        queryset=User.objects.filter(is_active=True), many=True
    )


class FacultySerializer(serializers.Serializer):
    faculty = serializers.PrimaryKeyRelatedField(
        queryset=User.objects.filter(is_active=True, user_type=User.UserType.FACULTY),
        allow_null=True,
    )


class ReasonSerializer(serializers.Serializer):
    reason = serializers.CharField(max_length=500)


class IssueUpdateSerializer(serializers.ModelSerializer):
    author = UserBriefSerializer(read_only=True)
    attachments = AttachmentSerializer(many=True, read_only=True)
    files = serializers.ListField(child=serializers.FileField(), required=False, write_only=True)

    class Meta:
        model = IssueUpdate
        fields = ["id", "author", "body", "status_to", "attachments", "files", "created_at", "edited_at"]
        read_only_fields = ["id", "author", "status_to", "attachments", "created_at", "edited_at"]


class RemarkSerializer(serializers.ModelSerializer):
    author = UserBriefSerializer(read_only=True)
    attachments = AttachmentSerializer(many=True, read_only=True)
    files = serializers.ListField(child=serializers.FileField(), required=False, write_only=True)

    class Meta:
        model = Remark
        fields = ["id", "author", "type", "body", "attachments", "files", "created_at", "edited_at"]
        read_only_fields = ["id", "author", "type", "attachments", "created_at", "edited_at"]


class IssueEventSerializer(serializers.ModelSerializer):
    actor = UserBriefSerializer(read_only=True)

    class Meta:
        model = IssueEvent
        fields = ["id", "actor", "actor_role", "action", "field", "old_value", "new_value", "created_at"]


class SupporterSerializer(serializers.Serializer):
    """A student on an issue, shown as 'Name (ROLL NO)'."""

    id = serializers.IntegerField(source="user.id")
    full_name = serializers.CharField(source="user.full_name")
    roll_number = serializers.CharField(source="user.roll_number")
    branch = serializers.CharField(source="user.branch")
    year_of_study = serializers.IntegerField(source="user.year_of_study", allow_null=True)
    avatar_url = serializers.SerializerMethodField()
    role = serializers.CharField()
    is_private = serializers.BooleanField()
    joined_at = serializers.DateTimeField()

    def get_avatar_url(self, obj) -> str:
        from apps.accounts.serializers import picture_url

        return picture_url(obj["user"], self.context.get("request"))


class SupportSerializer(serializers.Serializer):
    private = serializers.BooleanField(default=False)
