"use client";

import { useRouter } from "next/navigation";
import { useEffect } from "react";
import AppShell from "@/components/AppShell";
import { PageLoader } from "@/components/ui";
import { useAuth } from "@/lib/auth";

/** Every page in this folder needs a logged-in user. */
export default function PortalLayout({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading && !user) router.replace("/login");
  }, [loading, user, router]);

  if (loading || !user) return <PageLoader />;
  return <AppShell>{children}</AppShell>;
}
